

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="section-title">Reparación #<?php echo e($reparacion->id); ?></h3>

    <div class="mb-3">
        <strong>Cliente:</strong> <?php echo e($reparacion->cliente->nombre); ?> <?php echo e($reparacion->cliente->apellido); ?> <br>
        <strong>Vehículo:</strong> <?php echo e($reparacion->vehiculo->marca); ?> <?php echo e($reparacion->vehiculo->modelo); ?> <br>
        <strong>Estado:</strong> <?php echo e($reparacion->estado); ?> <br>
        <strong>Fecha de ingreso:</strong> <?php echo e($reparacion->fecha_ingreso); ?> <br>
        <strong>Total:</strong> $<?php echo e(number_format($reparacion->total, 2)); ?>

    </div>

    <h5>Detalle</h5>
    <p><?php echo e($reparacion->detalle); ?></p>

    <?php if($reparacion->observaciones): ?>
        <h5>Observaciones</h5>
        <p><?php echo e($reparacion->observaciones); ?></p>
    <?php endif; ?>

    <h5>Ítems cargados</h5>
    <table class="table table-sm table-bordered">
        <thead>
            <tr>
                <th>Tipo</th>
                <th>Detalle</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reparacion->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(ucfirst($item->tipo)); ?></td>
                    <td>
    <?php if($item->tipo === 'producto'): ?>
        <?php echo e(optional($item->producto)->nombre ?? 'Producto eliminado'); ?>

    <?php else: ?>
        <?php echo e(optional($item->servicio)->nombre ?? $item->nombre ?? 'Servicio eliminado'); ?>

    <?php endif; ?>
</td>
                    <td><?php echo e($item->cantidad); ?></td>
                    <td>$<?php echo e(number_format($item->precio_unitario, 2)); ?></td>
                    <td>$<?php echo e(number_format($item->subtotal, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <a href="<?php echo e(route('reparaciones.index')); ?>" class="btn btn-secondary  btn-custom">← Volver</a>
    <?php if($reparacion->estado !== 'Finalizado'): ?>
        <a href="<?php echo e(route('reparaciones.generarVenta', $reparacion)); ?>" class="btn btn-success float-end  btn-custom">💳 Generar Venta</a>
    
    
<hr>
<h5  class="section-title">Agregar producto o servicio</h5>

<form action="<?php echo e(route('reparaciones.addItem', $reparacion)); ?>" method="POST" class="row g-3">
    <?php echo csrf_field(); ?>
    <div class="col-md-2">
        <label>Tipo</label>
        <select name="tipo" class="form-select" required onchange="toggleTipo(this.value)">
            <option value="producto">Producto</option>
            <option value="servicio">Servicio</option>
        </select>
    </div>

    <div class="col-md-3" id="productoSelect">
        <label>Producto</label>
        <select name="producto_id" class="form-select" onchange="setPrecio(this)">
            <option value="">Seleccione</option>
    <?php $__currentLoopData = \App\Models\Producto::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($p->id); ?>" data-precio="<?php echo e($p->precio_venta); ?>"><?php echo e($p->nombre); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
    </div>

    <div class="col-md-3 d-none" id="servicioSelect">
        <label>Servicio</label>
        <select name="servicio_id" class="form-select" onchange="setPrecio(this)">
            <option value="">Seleccione</option>
    <?php $__currentLoopData = \App\Models\Servicio::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($p->id); ?>" data-precio="<?php echo e($p->precio); ?>"><?php echo e($p->nombre); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
    </div>

    <div class="col-md-2">
        <label>Cantidad</label>
        <input type="number" name="cantidad" class="form-control" value="1" required>
    </div>

    <div class="col-md-2">
        <label>Precio</label>
        <input type="number" name="precio_unitario" class="form-control" step="0.01" required>
    </div>
    <div class="col-12">
        <button class="btn btn-success">➕ Agregar Ítem</button>
    </div>
</form>

<script>
function toggleTipo(tipo) {
    document.getElementById('productoSelect').classList.toggle('d-none', tipo !== 'producto');
    document.getElementById('servicioSelect').classList.toggle('d-none', tipo !== 'servicio');
    document.querySelector('input[name="precio_unitario"]').value = '';
}

function setPrecio(select) {
    const selected = select.options[select.selectedIndex];
    const precio = selected.getAttribute('data-precio') || 0;
    document.querySelector('input[name="precio_unitario"]').value = precio;
}
</script>
</div><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/reparaciones/show.blade.php ENDPATH**/ ?>