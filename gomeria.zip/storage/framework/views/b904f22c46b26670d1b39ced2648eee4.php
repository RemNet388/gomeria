

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Vehículos</h2>

    <a href="<?php echo e(route('vehiculos.create')); ?>" class="btn btn-success mb-3 btn-custom">Agregar Vehículo</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Logo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($vehiculo->marca); ?></td>
                    <td><?php echo e($vehiculo->modelo); ?></td>
                    <td>
                        <?php if($vehiculo->logo): ?>
                            <img src="<?php echo e(asset('storage/' . $vehiculo->logo)); ?>" alt="Logo" width="60">
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('vehiculos.edit', $vehiculo)); ?>" class="btn btn-sm btn-primary">Editar</a>
                        <form action="<?php echo e(route('vehiculos.destroy', $vehiculo)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('¿Eliminar vehículo?')" class="btn btn-sm btn-danger btn-custom">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/vehiculos/index.blade.php ENDPATH**/ ?>