

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Listado de Ventas</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('ventas.create')); ?>" class="btn btn-primary mb-3 btn-custom">➕ Nueva Venta</a>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Forma de Pago</th>
                <th>Total</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($venta->id); ?></td>
                    <td><?php echo e($venta->cliente->nombre); ?> <?php echo e($venta->cliente->apellido); ?></td>
                    <td><?php echo e($venta->formaPago->nombre); ?></td>
                    <td>$ <?php echo e(number_format($venta->total, 2, ',', '.')); ?></td>
                    <td><?php echo e($venta->fecha); ?></td>
                    <td>
                        <a href="<?php echo e(route('ventas.show', $venta)); ?>" class="btn btn-sm btn-info">👁️ Ver</a>

                        <form action="<?php echo e(route('ventas.destroy', $venta)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar esta venta?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger btn-custom">🗑️ Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">No hay ventas registradas.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/ventas/index.blade.php ENDPATH**/ ?>