

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Generar Venta para Reparación #<?php echo e($reparacion->id); ?></h3>

    <form method="POST" action="<?php echo e(route('reparaciones.confirmarVenta', $reparacion)); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Forma de Pago</label>
            <select name="forma_pago_id" class="form-select" required>
                <option value="">Seleccione</option>
                <?php $__currentLoopData = $formasPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fp->id); ?>"><?php echo e($fp->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <h5>Resumen de Ítems</h5>
        <ul class="list-group mb-3">
            <?php $__currentLoopData = $reparacion->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <?php echo e($item->tipo === 'producto' ? $item->producto->nombre : $item->servicio->nombre); ?>

                    × <?php echo e($item->cantidad); ?> — $<?php echo e(number_format($item->subtotal, 2)); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div class="mb-3">
            <strong>Total: $<?php echo e(number_format($reparacion->items->sum('subtotal'), 2)); ?></strong>
        </div>

        <button class="btn btn-primary">💾 Confirmar y Generar Venta</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/reparaciones/generar_venta.blade.php ENDPATH**/ ?>