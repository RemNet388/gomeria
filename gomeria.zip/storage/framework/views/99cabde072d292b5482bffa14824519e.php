

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Movimientos del día</h2>

    <form method="GET" action="<?php echo e(route('caja.index')); ?>" class="row g-3 mb-3">
        <div class="col-auto">
            <label for="fecha" class="form-label">Fecha</label>
            <input type="date" name="fecha" id="fecha" class="form-control" value="<?php echo e($fecha); ?>">
        </div>
        <div class="col-auto align-self-end">
            <button type="submit" class="btn btn-primary btn-custom">Filtrar</button>
            <a href="<?php echo e(route('caja.cerrar', ['fecha' => $fecha])); ?>" class="btn btn-success btn-custom">
                ⚖️ Cerrar caja (PDF)
            </a>
        </div>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Hora</th>
                <th>Cliente</th>
                <th>Forma de Pago</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($venta->fecha->format('H:i')); ?></td>
                    <td><?php echo e($venta->cliente->nombre); ?> <?php echo e($venta->cliente->apellido); ?></td>
                    <td><?php echo e($venta->formaPago->nombre); ?></td>
                    <td>$ <?php echo e(number_format($venta->total, 2, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4">No hay movimientos.</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3">Total del día</th>
                <th>$ <?php echo e(number_format($total, 2, ',', '.')); ?></th>
            </tr>
        </tfoot>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/caja/index.blade.php ENDPATH**/ ?>