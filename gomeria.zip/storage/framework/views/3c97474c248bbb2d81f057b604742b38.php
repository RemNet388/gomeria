

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Formas de Pago</h2>
    <a href="<?php echo e(route('formas-pago.create')); ?>" class="btn btn-primary mb-3 btn-custom">Nueva forma</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $formas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($forma->nombre); ?></td>
                    <td>
                        <a href="<?php echo e(route('formas-pago.edit', $forma)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('formas-pago.destroy', $forma)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger btn-custom" onclick="return confirm('¿Eliminar?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/formas_pago/index.blade.php ENDPATH**/ ?>