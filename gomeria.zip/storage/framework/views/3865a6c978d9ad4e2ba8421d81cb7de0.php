

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Registrar Venta</h2>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('ventas.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
            <div class="col-md-4">
                <label>Cliente</label>
                <select name="cliente_id" class="form-select" required>
                    <option value="">Seleccione</option>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?> <?php echo e($cliente->apellido); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-4">
                <label>Forma de pago</label>
                <select name="forma_pago_id" class="form-select" required>
                    <option value="">Seleccione</option>
                    <?php $__currentLoopData = $formasPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fp->id); ?>"><?php echo e($fp->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <hr>

        <div id="itemsContainer"></div>

        <button type="button" id="addItemBtn" class="btn btn-secondary mb-3 btn-custom">➕ Agregar ítem</button>

        <div class="mb-3">
            <label>Total</label>
           <input type="number" id="totalInput" name="total" class="form-control" step="0.01" readonly>
        </div>

        <button type="submit" class="btn btn-success btn-custom">Registrar venta</button>
    </form>
</div>


<script>
    window.productos = <?php echo json_encode($productos, 15, 512) ?>;
    window.servicios = <?php echo json_encode($servicios, 15, 512) ?>;
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/ventas/create.blade.php ENDPATH**/ ?>