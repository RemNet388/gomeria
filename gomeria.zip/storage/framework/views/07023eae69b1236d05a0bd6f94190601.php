

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Listado de productos</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-primary mb-3 btn-custom">Agregar nuevo producto</a>
    <a href="<?php echo e(route('productos.stock')); ?>" class="btn btn-outline-secondary">📊 Ver Stock</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Foto</th>
                <th>Nombre</th>
                <th>Marca</th>
                <th>Medida</th>
                <th>Categoría</th>
                <th>Cantidad</th>
                <th>Precio Compra</th>
                <th>Precio Venta</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($producto->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $producto->foto)); ?>" width="60" height="60" style="object-fit: cover;">
                    <?php else: ?>
                        <span class="text-muted">Sin imagen</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->marca); ?></td>
                <td><?php echo e($producto->medida); ?></td>
                <td><?php echo e($producto->categoria); ?></td>
                <td><?php echo e($producto->cantidad); ?></td>
                <td>$<?php echo e(number_format($producto->precio_compra, 2)); ?></td>
                <td>$<?php echo e(number_format($producto->precio_venta, 2)); ?></td>
                <td>
                    <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                    <form action="<?php echo e(route('productos.destroy', $producto->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de eliminar este producto?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger btn-custom">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9">No hay productos cargados.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/productos/index.blade.php ENDPATH**/ ?>