<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm py-2">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold text-primary" href="<?php echo e(url('/')); ?>">
            AG - Gomeria
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="navbar-collapse show">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('productos.index')); ?>">📦 Productos</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('clientes.index')); ?>">👤 Clientes</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('vehiculos.index')); ?>">🚗 Vehículos</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('servicios.index')); ?>">🔧 Servicios</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('ventas.index')); ?>">💰 Ventas</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('reparaciones.index')); ?>">🛠️ Órdenes</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('caja.index')); ?>">📊 Caja</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('formas-pago.index')); ?>">💳 Formas de pago</a></li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item me-3 mt-1 text-end">
                    <span class="nav-link text-dark"><?php echo e(Auth::user()->name ?? 'Invitado'); ?></span>
                    <small class="text-muted ms-3 d-block">Gomería</small>
                </li>
                <li class="nav-item">
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger mt-2">Salir</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\gomeria\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>