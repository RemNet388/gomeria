<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema Integral</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container mt-4">
        <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm py-2">
        </div>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldContent('scripts'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\gomeria\resources\views/layouts/app.blade.php ENDPATH**/ ?>