

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3  class="section-title">Editar Reparación #<?php echo e($reparacion->id); ?></h3>

    <form action="<?php echo e(route('reparaciones.update', ['reparacion' => $reparacion->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Cliente</label>
            <select name="cliente_id" class="form-select" required>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" <?php echo e($reparacion->cliente_id == $c->id ? 'selected' : ''); ?>>
                        <?php echo e($c->nombre); ?> <?php echo e($c->apellido); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Vehículo</label>
            <select name="vehiculo_id" class="form-select" required>
                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->id); ?>" <?php echo e($reparacion->vehiculo_id == $v->id ? 'selected' : ''); ?>>
                        <?php echo e($v->marca); ?> <?php echo e($v->modelo); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Fecha de ingreso</label>
            <input type="date" name="fecha_ingreso" class="form-control" value="<?php echo e($reparacion->fecha_ingreso); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Estado</label>
            <select name="estado" class="form-select">
                <?php $__currentLoopData = ['Pendiente', 'En proceso', 'Finalizado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($estado); ?>" <?php echo e($reparacion->estado == $estado ? 'selected' : ''); ?>>
                        <?php echo e($estado); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Detalle</label>
            <textarea name="detalle" class="form-control" rows="3"><?php echo e($reparacion->detalle); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Observaciones</label>
            <textarea name="observaciones" class="form-control" rows="2"><?php echo e($reparacion->observaciones); ?></textarea>
        </div>

        <button class="btn btn-primary  btn-custom">💾 Actualizar Reparación</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/reparaciones/edit.blade.php ENDPATH**/ ?>