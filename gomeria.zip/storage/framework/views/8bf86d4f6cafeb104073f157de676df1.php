

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="section-title">Agregar cliente</h1>

    <form action="<?php echo e(route('clientes.store')); ?>" method="POST">
        <?php echo $__env->make('clientes.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button type="submit" class="btn btn-success btn-custom">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/clientes/create.blade.php ENDPATH**/ ?>