

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Detalle de Venta #<?php echo e($venta->id); ?></h2>

    <div class="mb-3">
        <strong>Cliente:</strong> <?php echo e($venta->cliente->nombre); ?> <?php echo e($venta->cliente->apellido); ?> <br>
        <strong>Forma de Pago:</strong> <?php echo e($venta->formaPago->nombre); ?> <br>
        <strong>Fecha:</strong> <?php echo e($venta->fecha); ?> <br>
        <strong>Total:</strong> $ <?php echo e(number_format($venta->total, 2, ',', '.')); ?>

    </div>

    <h5>Ítems vendidos:</h5>

    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>Tipo</th>
                <th>Descripción</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $venta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($detalle->producto_id): ?>
                            Producto
                        <?php elseif($detalle->servicio_id): ?>
                            Servicio
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($detalle->producto_id): ?>
                            <?php echo e($detalle->producto->nombre); ?>

                        <?php elseif($detalle->servicio_id): ?>
                            <?php echo e($detalle->servicio->nombre); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($detalle->cantidad); ?></td>
                    <td>$ <?php echo e(number_format($detalle->precio_unitario, 2, ',', '.')); ?></td>
                    <td>$ <?php echo e(number_format($detalle->subtotal, 2, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <a href="<?php echo e(route('ventas.index')); ?>" class="btn btn-secondary mt-3 btn-custom">⬅️ Volver al listado</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/ventas/show.blade.php ENDPATH**/ ?>