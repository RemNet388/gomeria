

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">🛠️ Servicios</h2>
    <a href="<?php echo e(route('servicios.create')); ?>" class="btn btn-success mb-3 btn-custom">➕ Nuevo Servicio</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($servicio->id); ?></td>
                    <td><?php echo e($servicio->nombre); ?></td>
                    <td><?php echo e($servicio->descripcion); ?></td>
                    <td>$<?php echo e(number_format($servicio->precio, 2, ',', '.')); ?></td>
                    <td>
                        <a href="<?php echo e(route('servicios.edit', $servicio)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('servicios.destroy', $servicio)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger btn-custom" onclick="return confirm('¿Eliminar este servicio?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/servicios/index.blade.php ENDPATH**/ ?>