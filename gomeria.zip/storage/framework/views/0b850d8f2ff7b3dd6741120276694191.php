

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="section-title">Agregar nuevo producto</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Oops!</strong> Hubo algunos errores:<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('productos.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre *</label>
            <input type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" required>
        </div>

        <div class="mb-3">
            <label for="marca" class="form-label">Marca</label>
            <input type="text" name="marca" class="form-control" value="<?php echo e(old('marca')); ?>">
        </div>

        <div class="mb-3">
            <label for="medida" class="form-label">Medida</label>
            <input type="text" name="medida" class="form-control" value="<?php echo e(old('medida')); ?>">
        </div>

        <div class="mb-3">
            <label for="cantidad" class="form-label">Cantidad *</label>
            <input type="number" name="cantidad" class="form-control" value="<?php echo e(old('cantidad', 0)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="precio_compra" class="form-label">Precio de compra</label>
            <input type="number" step="0.01" name="precio_compra" class="form-control" value="<?php echo e(old('precio_compra')); ?>">
        </div>

        <div class="mb-3">
            <label for="precio_venta" class="form-label">Precio de venta</label>
            <input type="number" step="0.01" name="precio_venta" class="form-control" value="<?php echo e(old('precio_venta')); ?>">
        </div>

        <div class="mb-3">
            <label for="categoria" class="form-label">Categoría *</label>
            <select name="categoria" class="form-select" required>
                <option value="">-- Seleccione --</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat); ?>" <?php echo e(old('categoria') == $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="foto" class="form-label">Foto</label>
            <input type="file" name="foto" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary btn-custom">Guardar producto</button>
        <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary">Volver</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/productos/create.blade.php ENDPATH**/ ?>