

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3  class="section-title">Listado de Reparaciones</h3>
    <a href="<?php echo e(route('reparaciones.create')); ?>" class="btn btn-primary mb-3  btn-custom">➕ Nueva Reparación</a>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Vehículo</th>
                <th>Estado</th>
                <th>Fecha Ingreso</th>
                <th>Total</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reparaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($reparacion->id); ?></td>
        <td><?php echo e($reparacion->cliente->nombre ?? 'Sin cliente'); ?></td>
        <td><?php echo e($reparacion->vehiculo->marca ?? ''); ?> <?php echo e($reparacion->vehiculo->modelo ?? ''); ?></td>
        <td><?php echo e($reparacion->estado); ?></td>
        <td><?php echo e($reparacion->total); ?></td>
        <td>
            <a href="<?php echo e(route('reparaciones.show', $reparacion)); ?>" class="btn btn-sm btn-primary">Ver</a>
            <a href="<?php echo e(route('reparaciones.edit', $reparacion)); ?>" class="btn btn-sm btn-warning">Editar</a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gomeria\resources\views/reparaciones/index.blade.php ENDPATH**/ ?>